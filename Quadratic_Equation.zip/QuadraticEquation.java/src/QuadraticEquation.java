import javax.swing.JOptionPane;

public class QuadraticEquation {

    public static void main(String[] args) {

        String aInput = JOptionPane.showInputDialog(null, "Enter value for a:");
        String bInput = JOptionPane.showInputDialog(null, "Enter value for b:");
        String cInput = JOptionPane.showInputDialog(null, "Enter value for c:");

        double a = Double.parseDouble(aInput);
        double b = Double.parseDouble(bInput);
        double c = Double.parseDouble(cInput);

        double discriminant = b * b - 4 * a * c;
        System.out.println(discriminant);

        String root1, root2;

        if (discriminant > 0) {
            double r1 = (-b + Math.sqrt(discriminant)) / (2 * a);
            double r2 = (-b - Math.sqrt(discriminant)) / (2 * a);
            root1 = String.format("Root1: %.2f", r1);
            root2 = String.format("Root2: %.2f", r2);
        } else if (discriminant == 0) {
            double r = -b / (2 * a);
            root1 = String.format("Root1: %.2f", r);
            root2 = "";
        } else {
            double realPart = -b / (2 * a);
            double imaginaryPart = Math.sqrt(-discriminant) / (2 * a);
            root1 = String.format("Root1: %.2f + %.2fi", realPart, imaginaryPart);
            root2 = String.format("Root2: %.2f - %.2fi", realPart, imaginaryPart);
        }

        String message = root1;

        if (!root2.isEmpty()) {
            message +="\n" + root2;
        }
      
        JOptionPane.showMessageDialog(null, message, "Quadratic Equation Roots", JOptionPane.INFORMATION_MESSAGE);
    }
}

